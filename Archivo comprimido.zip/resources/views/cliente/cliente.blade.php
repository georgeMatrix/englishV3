@extends('layouts.app')
@section('content')
    <cliente-component></cliente-component>
    @endsection
