@extends('layouts.app')
@section('content')
    <control-component></control-component>
    @endsection
