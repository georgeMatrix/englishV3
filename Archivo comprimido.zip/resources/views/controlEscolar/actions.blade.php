<a href="{{ route('controlEscolar.edit', $id) }}" class="btn btn-primary btn-sm"><i class="far fa-edit"></i></a>
