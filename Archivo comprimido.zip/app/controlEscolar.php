<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class controlEscolar extends Model
{
    //
}
